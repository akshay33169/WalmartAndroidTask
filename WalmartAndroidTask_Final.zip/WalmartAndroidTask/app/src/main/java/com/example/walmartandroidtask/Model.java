package com.example.walmartandroidtask;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class Model extends AppCompatActivity {

    @Nullable
    String city, state;

    /*
        Constructor to initialize the strings with values once object is declared.

     */
    public Model(String cityName, String stateName) {
        city = cityName;
        state = stateName;
    }


    //Get and set methods below

    public String getCity() {
        return city;
    }

    public void setCity(String cityName) {
        this.city = cityName;

    }

    public String getState() {
        return state;
    }

    public void setState(String stateName) {
        this.state = stateName;
    }

    public List<String> getZipCodes() {

        return null;
    }


}