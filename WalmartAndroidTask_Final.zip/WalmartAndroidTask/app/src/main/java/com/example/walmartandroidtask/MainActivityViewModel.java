package com.example.walmartandroidtask;

import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collections;
import java.util.List;

public class MainActivityViewModel extends BaseObservable {

    public static Model model;

    private String successMessage = "Successfully submitted";
    private String errorMessage = "No results found";



    private String toastMessage = null;
    private String textView3 =null;

    static int calculateZipCodes = 0;

    // getter and setter methods
    // for toast message

    @Bindable
    public String getToastMessage() {
        return toastMessage;
    }

    private void setToastMessage(String toastMessage) {
        this.toastMessage = toastMessage;
        notifyPropertyChanged(BR.toastMessage);
    }


    //getter and setter methods
    //for city state

    @Bindable
    public String getCity(){return model.city; }

    public void setCity(String cityName)
    {
        model.city = cityName;
        notifyPropertyChanged(BR.city);

        System.out.println("DEBUGGING CITY "+model.city);

    }

    @Bindable
    public String getState()
    {
        return model.state;
    }

    public void setState(String stateName)
    {
        model.state = stateName;
        notifyPropertyChanged(BR.state);

        System.out.println("DEBUGGING STATE "+model.state);
    }

    //getters and setters for textView3

    @Bindable
    public String getTextView3()
    {
        return textView3;
    }

    public void setTextView3(String zipCodes )
    {
        textView3 = zipCodes;
        notifyPropertyChanged(BR.textView3);

    }

    // constructor of ViewModel class
    public MainActivityViewModel() {

        // instantiating object of
        // model class
        model = new Model("","");
    }

    // actions to be performed
    // when user clicks
    // the LOGIN button
    public void onButtonClicked() {
        if (isValid()) {
            setToastMessage(successMessage);

          //  System.out.println("PRINTING MODEL CITY"+model.city);
          //  System.out.println("PRINTING MODEL STATE"+model.state);
//            zipcodesList = model.getZipCodes();


            final List<String>[] result = new List[]{Collections.singletonList("")};

            Model model = MainActivityViewModel.model;
            // Instantiate the RequestQueue.


          // RequestQueue queue = new RequestQueue(MainActivity.this);


        //    System.out.println("city is " + model.city);
        //    System.out.println("state is " + model.state);
            String url = "https://www.zipcodeapi.com/rest/FghVhUg7nNfbjpHvViO9ps9DFw5rq8WHvleFsNC6jzSQvwM0KQPjhkGBqOKPAIIZ/city-zips.json/" + model.city + "/" + model.state + "";

            if (model.city != null && model.state != null) {
                // Request a string response from the provided URL.
                final StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                // Display the first 500 characters of the response string.
                                //textView.setText("Response is: "+ response.substring(0,500));
                                System.out.println("Response is " + response);
                                String strParse = "";


                                try {

                                    //create json object equal to response and parse out the list of strings into result
                                    JSONObject obj = new JSONObject(response);

                                    strParse = obj.getString("zip_codes");

                                 //   result[0] = Arrays.asList(strParse.substring(1, strParse.length() - 1).split(","));

                                    System.out.println("result is " + result);


                                    setTextView3(strParse);
                                    //update recycler view

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //textView.setText("That didn't work!");
                        System.out.println("That didn't work!");



                    }
                });


                VolleySingleton.getInstance(Cliente.getAppContext()).addToRequestQueue(stringRequest);

                // Add the request to the RequestQueue.
                //queue.add(stringRequest);


            }



        }
        else
            setToastMessage(errorMessage);
    }


    public boolean isValid()
    {
        if(!model.getCity().isEmpty() && !model.getState().isEmpty())
        {

            return true;
        }

        return false;

    }



}


